import { Jumbotron } from "react-bootstrap"
const Error = () => {
  return (
    <div>
      <Jumbotron>
        <h1>404 - Not Found!</h1>
      </Jumbotron>
    </div>
  )
}

export default Error
